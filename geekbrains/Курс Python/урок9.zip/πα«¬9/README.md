
* Ссылка для установки среды и активации: https://github.com/python-telegram-bot/python-telegram-bot 

* Бот телеграм: @SberDeafBot

* Запуск командой: python main.py (Для задач 1 - 2.1)

* Задача 1: Cоздайте в папке проекта файл 'token.txt' и поместите туда токен для работы c @SberDeafBot

* Задача 2.2: Запустите bot.py
