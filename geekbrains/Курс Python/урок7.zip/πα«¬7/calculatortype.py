def type():
    type = input('С какими числами вы собираетесь работать? (Complex/Rational): ').lower()
    return type